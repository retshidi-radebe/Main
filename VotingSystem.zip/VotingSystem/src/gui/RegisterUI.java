package gui;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import session.Session;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;

public class RegisterUI extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField usernameTf;
	private Session session;
	private JTextField studentNoTf;
	private JPasswordField passwordTf;
	private JFrame jframe = new JFrame();

	/**
	 * Create the panel.
	 */
	public RegisterUI(Session session) {
		this.session = session;
		
		setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("Register");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel.setBackground(new Color(231, 84, 14));
		lblNewLabel.setIcon(new ImageIcon(RegisterUI.class.getResource("/resources/uj.jpg")));
		lblNewLabel.setOpaque(true);
		add(lblNewLabel, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton registerBtn = new JButton("Register");
		
		registerBtn.setBounds(29, 241, 117, 40);
		panel.add(registerBtn);
		
		JButton loginBtn = new JButton("Login");
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new LoginUI(session);
				jframe.dispose();
			}
		});
		loginBtn.setBounds(198, 241, 117, 40);
		panel.add(loginBtn);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setBounds(37, 32, 278, 13);
		panel.add(lblNewLabel_1);
		
		usernameTf = new JTextField();
		usernameTf.setBounds(34, 55, 281, 19);
		panel.add(usernameTf);
		usernameTf.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Password");
		lblNewLabel_1_1.setBounds(40, 105, 275, 13);
		panel.add(lblNewLabel_1_1);
		
		studentNoTf = new JTextField();
		studentNoTf.setColumns(10);
		studentNoTf.setBounds(37, 201, 281, 19);
		panel.add(studentNoTf);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Student Number");
		lblNewLabel_1_1_1.setBounds(40, 178, 275, 13);
		panel.add(lblNewLabel_1_1_1);
		
		passwordTf = new JPasswordField();
		passwordTf.setBounds(37, 132, 278, 19);
		panel.add(passwordTf);
		
		registerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				session.getDataAccessObject().addUser(usernameTf.getText(), passwordTf.getText(), studentNoTf.getText());
		        JOptionPane.showMessageDialog(null, "User saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
		        new LoginUI(session);
		        jframe.dispose();
			}
		});
		
		createFrame();
	}

	
	private void createFrame() {
		try {
			jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jframe.setSize(360, 455);
			jframe.setLocationRelativeTo(null); 
			jframe.getRootPane().putClientProperty("JRootPane.titleBarBackground", new Color(231, 84, 14));
			jframe.getRootPane().putClientProperty("JRootPane.titleBarForeground", Color.white);
			jframe.getContentPane().setLayout(new BorderLayout());
			jframe.getContentPane().add(this, BorderLayout.CENTER);
			jframe.setVisible(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
