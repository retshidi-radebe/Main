package gui;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import session.Session;
import javax.swing.SwingConstants;

import database.User;

import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginUI extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField usernameTf;
	private Session session;
	private JPasswordField passwordTf;
	private JFrame jframe = new JFrame();

	/**
	 * Create the panel.
	 */
	public LoginUI(Session session) {
		this.session = session;
		
		setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel.setBackground(new Color(231, 84, 14));
		lblNewLabel.setIcon(new ImageIcon(RegisterUI.class.getResource("/resources/uj.jpg")));
		lblNewLabel.setOpaque(true);
		add(lblNewLabel, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton loginBtn = new JButton("Login");
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User logged = session.getDataAccessObject().getUser(usernameTf.getText(), passwordTf.getText());
				if(logged != null) {
					session.setLoggedInUser(logged); 
					new VoteCategoryUI(session);
					jframe.dispose();
				} else {
				    JOptionPane.showMessageDialog(null, "Incorrect Password or Username.", "Error", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		loginBtn.setBounds(29, 190, 117, 40);
		panel.add(loginBtn);
		
		JButton registerBtn = new JButton("Register");
		registerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RegisterUI(session);
				jframe.dispose();
			}
		});
		registerBtn.setBounds(198, 190, 117, 40);
		panel.add(registerBtn);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setBounds(37, 32, 278, 13);
		panel.add(lblNewLabel_1);
		
		usernameTf = new JTextField();
		usernameTf.setBounds(34, 55, 281, 19);
		panel.add(usernameTf);
		usernameTf.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Password");
		lblNewLabel_1_1.setBounds(40, 105, 275, 13);
		panel.add(lblNewLabel_1_1);
		
		passwordTf = new JPasswordField();
		passwordTf.setBounds(34, 135, 281, 19);
		panel.add(passwordTf);

		createFrame();
	}
	
	private void createFrame() {
		try {
			jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jframe.setSize(360, 395);
			jframe.setLocationRelativeTo(null); 
			jframe.getRootPane().putClientProperty("JRootPane.titleBarBackground", new Color(231, 84, 14));
			jframe.getRootPane().putClientProperty("JRootPane.titleBarForeground", Color.white);
			jframe.getContentPane().setLayout(new BorderLayout());
			jframe.getContentPane().add(this, BorderLayout.CENTER);
			jframe.setVisible(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
