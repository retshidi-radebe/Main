package gui;

import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.Color;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;

import acsse.csc03a3.Transaction;
import database.Candidate;
import session.Session;

import java.awt.Font;
import java.awt.FlowLayout;

public class VoteCategoryUI extends JPanel {

	private static final long serialVersionUID = 1L;

	private JFrame jframe = new JFrame();
	@SuppressWarnings("unused")
	private Session session;
	
	/**
	 * Create the panel.
	 */
	public VoteCategoryUI(Session session) {
		this.session = session;
		
		setBackground(new Color(231, 84, 14));
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(231, 84, 14));
		add(panel, BorderLayout.NORTH);
		panel.setLayout(new GridLayout(2, 0, 0, 0));
		
		JLabel lblNewLabel = new JLabel("Category");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 32));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Select catagory in which you would like to vote in.");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(231, 84, 14));
		add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new GridLayout(0, 3, 50, 50));
		
		JButton btnNewButton = new JButton("President");
		btnNewButton.setIcon(new ImageIcon(VoteCategoryUI.class.getResource("/resources/PRESIDENT.png")));
		btnNewButton.setBackground(new Color(255, 128, 64));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.putClientProperty("JButton.roundRect", true);
		panel_1.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!session.getDataAccessObject().checkIfVoted(session.getLoggedInUser().getStudentNo(), "President")) {
				    JOptionPane.showMessageDialog(null, "Already voted for a President.", "Error", JOptionPane.WARNING_MESSAGE);
				} else {
					new VotingUI(session, "President");
					jframe.dispose();
				}
			}
		});
		
		
		JButton btnNewButton_1 = new JButton("Treasure");
		btnNewButton_1.setIcon(new ImageIcon(VoteCategoryUI.class.getResource("/resources/TREASURER.png")));
		btnNewButton_1.setBackground(new Color(255, 128, 64));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.putClientProperty("JButton.roundRect", true);
		panel_1.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!session.getDataAccessObject().checkIfVoted(session.getLoggedInUser().getStudentNo(), "President")) {
				    JOptionPane.showMessageDialog(null, "Already voted for a Treasure.", "Error", JOptionPane.WARNING_MESSAGE);
				} else {
					new VotingUI(session, "Treasure");
					jframe.dispose();
				}
			}
		});
		
		JButton btnNewButton_2 = new JButton("Secretary");
		btnNewButton_2.setIcon(new ImageIcon(VoteCategoryUI.class.getResource("/resources/SECRETARY.png")));
		btnNewButton_2.setBackground(new Color(255, 128, 64));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.putClientProperty("JButton.roundRect", true);
		panel_1.add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!session.getDataAccessObject().checkIfVoted(session.getLoggedInUser().getStudentNo(), "President")) {
				    JOptionPane.showMessageDialog(null, "Already voted for a Secretary.", "Error", JOptionPane.WARNING_MESSAGE);
				} else {
					new VotingUI(session, "Secretary");
					jframe.dispose();
				}
			}
		});
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(231, 84, 14));
		add(panel_2, BorderLayout.SOUTH);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(VoteCategoryUI.class.getResource("/resources/uj.jpg")));
		panel_2.add(lblNewLabel_2, BorderLayout.WEST);
		
		JLabel usernameLbl = new JLabel(session.getLoggedInUser().getUsername());
		usernameLbl.setFont(new Font("Tahoma", Font.PLAIN, 17));
		usernameLbl.setHorizontalAlignment(SwingConstants.CENTER);
		usernameLbl.setForeground(new Color(255, 255, 255));
		panel_2.add(usernameLbl, BorderLayout.CENTER);
		
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new LoginUI(session);
				jframe.dispose();
			}
		});
		btnNewButton_3.setIcon(new ImageIcon(VoteCategoryUI.class.getResource("/resources/exit.png")));
		panel_2.add(btnNewButton_3, BorderLayout.EAST);
		
		createFrame();
	}
	
	private void createFrame() {
		try {
			jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jframe.setExtendedState(JFrame.MAXIMIZED_BOTH); 
			jframe.setLocationRelativeTo(null); 
			jframe.getRootPane().putClientProperty("JRootPane.titleBarBackground", new Color(231, 84, 14));
			jframe.getRootPane().putClientProperty("JRootPane.titleBarForeground", Color.white);
			jframe.getContentPane().setLayout(new BorderLayout());
			jframe.getContentPane().add(this, BorderLayout.CENTER);
			jframe.setVisible(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
