package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import acsse.csc03a3.Transaction;
import database.Candidate;
import session.Session;

public class VotingUI extends JPanel {
	private static final long serialVersionUID = 1L;

	private JFrame jframe = new JFrame();
	private Session session;
	
	/**
	 * Create the panel.
	 */
	public VotingUI(Session session, String category) {
		this.session = session;
		
		setBackground(new Color(231, 84, 14));
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(231, 84, 14));
		add(panel, BorderLayout.NORTH);
		panel.setLayout(new GridLayout(2, 0, 0, 0));
		
		JLabel lblNewLabel = new JLabel("Candidate");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 32));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Select individual you would like to vote for");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel_1);
		
		JPanel candidates = new JPanel();
		candidates.setBackground(new Color(231, 84, 14));
		add(candidates, BorderLayout.CENTER);
		candidates.setLayout(new GridLayout(0, 3, 50, 50));
		
		
		for(Candidate cat : session.getDataAccessObject().getCandidatesByCategory(category)) {
			candidates.add(candidateOption(cat));
		}
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(231, 84, 14));
		add(panel_2, BorderLayout.SOUTH);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(RegisterUI.class.getResource("/resources/uj.jpg")));
		panel_2.add(lblNewLabel_2, BorderLayout.WEST);

		JLabel usernameLbl = new JLabel(session.getLoggedInUser().getUsername());
		usernameLbl.setFont(new Font("Tahoma", Font.PLAIN, 19));
		usernameLbl.setHorizontalAlignment(SwingConstants.CENTER);
		usernameLbl.setForeground(new Color(255, 255, 255));
		panel_2.add(usernameLbl, BorderLayout.CENTER);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new VoteCategoryUI(session);
				jframe.dispose();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(VotingUI.class.getResource("/resources/home.png")));
		panel_2.add(btnNewButton_1, BorderLayout.EAST);

		createFrame();

	}
	
	public JButton candidateOption(Candidate candidate) { 
		JButton btnNewButton = new JButton(candidate.getName());
		btnNewButton.setIcon(new ImageIcon(RegisterUI.class.getResource("/resources/blank-avatar-profile-picture-vector-45161169.png")));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.putClientProperty("JButton.roundRect", true);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Transaction<Candidate> transaction = new Transaction<Candidate>(session.getLoggedInUser().getStudentNo(), candidate.getName(), candidate);
				session.addTransactionToTransactions(transaction);
				if(session.getBlockchain().isChainValid()) {
					session.getDataAccessObject().saveVotesToDatabase(transaction);
				}
				JOptionPane.showMessageDialog(null, "Vote to "+candidate.getName()+" Logged.", "Success", JOptionPane.INFORMATION_MESSAGE);
				new VoteCategoryUI(session);
				jframe.dispose();
			}
		});
		return btnNewButton; 
	}
	
	private void createFrame() {
		try {
			jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Default close operation
			jframe.setExtendedState(JFrame.MAXIMIZED_BOTH); 
			jframe.setLocationRelativeTo(null); 
			jframe.getRootPane().putClientProperty("JRootPane.titleBarBackground", new Color(231, 84, 14));
			jframe.getRootPane().putClientProperty("JRootPane.titleBarForeground", Color.white);
			jframe.getContentPane().setLayout(new BorderLayout());
			jframe.getContentPane().add(this, BorderLayout.CENTER);
			jframe.setVisible(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
