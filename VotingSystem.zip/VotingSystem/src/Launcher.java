import java.awt.BorderLayout;
import java.awt.Color; 

import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf; 

import gui.LoginUI;
import session.Session;

public class Launcher {

	public static void main(String[] args) {

		// Set FlatLaf look and feel
		try {
			UIManager.setLookAndFeel(new FlatDarkLaf());
	        UIManager.put("Button.background", new Color(231, 84, 14));
	        UIManager.put("Button.focus", new Color(231, 84, 14)); 
	        UIManager.put("Button.select", new Color(231, 84, 14));
	        UIManager.put("Button.foreground", Color.WHITE);
	        UIManager.put("Button.arc", 30 );
	        UIManager.put("TextComponent.arc", 30 );
	        UIManager.put("TextComponent.borderLineColor", new Color(231, 84, 14));


		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  

		Session session = new Session();
		LoginUI loginPanel = new LoginUI(session);

		

	}


}
