package database;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale.Category;

import org.apache.commons.codec.digest.DigestUtils;

import acsse.csc03a3.Transaction;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {


	private final String SELECT_VOTED_CATEGORY_SQL = 
			"SELECT * FROM votes WHERE voter = ? AND category = ?";
	
	private final String SELECT_CANDICATES_SQL = 
			"SELECT * FROM candidates";
	

	private final String SELECT_CANDICATES_CATEGORY_SQL = 
			"SELECT * FROM candidates WHERE category = ?";

	private final String SELECT_USER_BY_USERNAME_AND_PASSWORD_SQL = 
			"SELECT * FROM users WHERE username = ? AND password = ?";

	private final String INSERT_CANDIDATE_SQL = 
			"INSERT INTO candidates (name,category) VALUES (?,?)";

	private final String INSERT_USER_SQL = 
			"INSERT INTO users (username, password, studentNo) VALUES (?, ?, ?)";

	private final String CREATE_USERS_TABLE_SQL =
			"CREATE TABLE users (" +
					"id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
					"username VARCHAR(100) UNIQUE NOT NULL," +
					"password VARCHAR(100) NOT NULL," +
					"studentNo VARCHAR(100) NOT NULL" +
					")";

	private final String CREATE_CANDIDATES_TABLE_SQL =
			"CREATE TABLE candidates (" +
					"id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
					"name VARCHAR(100) NOT NULL," +
					"category VARCHAR(100) NOT NULL" +
					")";

	private final String CREATE_VOTES_TABLE_SQL =
			"CREATE TABLE votes (" +
					"id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
					"voter VARCHAR(100) NOT NULL," +
					"candidate VARCHAR(100) NOT NULL," +
					"category VARCHAR(100) NOT NULL," +
					"vote_timestamp BIGINT NOT NULL" +
					")";

	private Connection connection;

	private DatabaseConnection dbConnection;

	public DAO() {
		File folder = new File("database");
        if (folder.exists() && folder.isDirectory()) {
    		dbConnection = new DatabaseConnection();
    		connection = dbConnection.getConnection(); 
        } else {
    		dbConnection = new DatabaseConnection();
    		connection = dbConnection.getConnection(); 
    		createDatabase();
    		createCandidates();
        };
	}

	public boolean addUser(String username, String password, String studentNo) {
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_USER_SQL);
			statement.setString(1, username);
			statement.setString(2, DigestUtils.md5Hex(password));
			statement.setString(3, studentNo);
			int rowsAffected = statement.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean addCandidate(String name, String category) {
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_CANDIDATE_SQL);
			statement.setString(1, name);
			statement.setString(2, category);
			int rowsAffected = statement.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public User getUser(String username, String password) {
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_USER_BY_USERNAME_AND_PASSWORD_SQL);
			statement.setString(1, username);
			statement.setString(2, DigestUtils.md5Hex(password));
			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					String dbUsername = resultSet.getString("username");
					String dbPassword = resultSet.getString("password");
					String studentNo = resultSet.getString("studentNo");
					return new User(dbUsername, dbPassword, studentNo);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
 

	public ArrayList<Candidate> getCandidatesByCategory(String category) {
		ArrayList<Candidate> candidates = new ArrayList<>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_CANDICATES_CATEGORY_SQL);
			statement.setString(1, category);
			try (ResultSet resultSet = statement.executeQuery()) {
				while (resultSet.next()) {
					String name = resultSet.getString("name");
					String categoryF = resultSet.getString("category");
					int id = resultSet.getInt("id"); 
					candidates.add(new Candidate(name,id,categoryF));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return candidates;
	}

	public ArrayList<Candidate> getAllCandidates() {
		ArrayList<Candidate> candidates = new ArrayList<>();
		try {
			Statement statement = connection.createStatement(); 
			try (ResultSet resultSet = statement.executeQuery(SELECT_CANDICATES_SQL)) {
				while (resultSet.next()) {
					String name = resultSet.getString("name");
					String category = resultSet.getString("category");
					int id = resultSet.getInt("id"); 
					candidates.add(new Candidate(name,id,category));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return candidates;
	}
 

	public boolean checkIfVoted(String category, String voter) {
		ArrayList<Candidate> candidates = new ArrayList<>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_VOTED_CATEGORY_SQL);
	        statement.setString(1, voter);
	        statement.setString(2, category);  
			try (ResultSet resultSet = statement.executeQuery()) {
				while (resultSet.next()) {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	 
	
	private void createCandidates() {
		addCandidate("Brandon","President");
		addCandidate("Tlale","President");
		addCandidate("Thato","President");
		addCandidate("Tebello","President");
		

		addCandidate("Tebogo","Treasure");
		addCandidate("John","Treasure");
		addCandidate("Joy","Treasure");
		addCandidate("Tshepiso","Treasure");
		addCandidate("Simon","Treasure");
		addCandidate("Michael","Treasure");
		

		addCandidate("Mathabo","Secretary");
		addCandidate("Thabiso","Secretary");
		addCandidate("Joyce","Secretary");
		addCandidate("Martha","Secretary");
		addCandidate("Elizabeth","Secretary");
		addCandidate("Jessica","Secretary");
		
		System.out.println("Candidates created successfully.");
	}

	private void createDatabase() {
		try {
			// Create users table
			createTable(connection, CREATE_USERS_TABLE_SQL);

			// Create candidates table
			createTable(connection, CREATE_CANDIDATES_TABLE_SQL);

			// Create votes table
			createTable(connection, CREATE_VOTES_TABLE_SQL);

			System.out.println("Database and tables created successfully.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void createTable(Connection connection, String createTableSQL) throws SQLException {
		try (Statement statement = connection.createStatement()) {
			statement.executeUpdate(createTableSQL);
		}
	}

	public void saveVotesToDatabase(Transaction transaction) {
		try {
			String sql = "INSERT INTO votes (voter, candidate, vote_timestamp, category) VALUES (?, ?, ?, ?)";
			PreparedStatement statement = connection.prepareStatement(sql);

			System.out.print("Saving vote : " + transaction.getSender() + " " + ((Candidate)transaction.getData()).getCategory());
			
			if(transaction != null) {
				statement.setString(1, transaction.getSender().trim());
				statement.setString(2, transaction.getReceiver());
				statement.setLong(3, transaction.getTimestamp());
				statement.setString(4, ((Candidate)transaction.getData()).getCategory().trim());
				statement.executeUpdate();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public boolean hasVoted(String studentNo, String category) {
		  PreparedStatement pstmt = null;
	        ResultSet rs = null;

	        try { 
	            // Define the SQL query with placeholders
	            String query = "SELECT * FROM votes WHERE voter = ? AND category = ?";

	            // Create a prepared statement with the query
	            pstmt = connection.prepareStatement(query);

	            // Set parameters
	            pstmt.setString(1, studentNo.trim());
	            pstmt.setString(2, category.trim());

	            // Execute the query
	            rs = pstmt.executeQuery();

	            // Check if the result set is empty
	            return rs.next(); // Returns true if the result set is not empty, false otherwise
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false; // Return false in case of any exception
	        } 
	}

}
