package database;

public class User { 
	private String username;
	private String studentNo;
	private String password;

	public User(String username, String password, String studentNo) {
		this.username = username;
		this.password = password;
		this.studentNo = studentNo;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}

	@Override
	public String toString() {
		return "UserDTO{" +
				"username='" + username + '\'' +
				", password='" + password + '\'' +
				'}';
	}

}
