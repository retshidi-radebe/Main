package session;

import java.util.ArrayList;
import java.util.List;

import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;
import database.Candidate;
import database.DAO;
import database.User;

public class Session {

    private Blockchain<Candidate> blockchain = new Blockchain<>();
    private List<Transaction<Candidate>> transactions = new ArrayList<Transaction<Candidate>>();
    
	private DAO dataAccessObject;
	private User loggedInUser;
	
	public Session() {
		dataAccessObject = new DAO();
	}
	
	public DAO getDataAccessObject() {
		return dataAccessObject;
	}

	public User getLoggedInUser() {
		return loggedInUser;
	}

	public void setLoggedInUser(User loggedInUser) {
        blockchain.registerStake(loggedInUser.getStudentNo(), 100);
		this.loggedInUser = loggedInUser;
	}

	public Blockchain<Candidate> getBlockchain() {
		return blockchain;
	}

	public void setBlockchain(Blockchain<Candidate> blockchain) {
		this.blockchain = blockchain;
	} 

	public void addTransactionToTransactions(Transaction<Candidate> transaction) {
		transactions.add(transaction);
        blockchain.addBlock(transactions);
		
	}
}
